<?php

namespace ContainerSPtvMhk;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder6f976 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer6169f = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties8b405 = [
        
    ];

    public function getConnection()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getConnection', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getMetadataFactory', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getExpressionBuilder', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'beginTransaction', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getCache', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getCache();
    }

    public function transactional($func)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'transactional', array('func' => $func), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'wrapInTransaction', array('func' => $func), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'commit', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->commit();
    }

    public function rollback()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'rollback', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getClassMetadata', array('className' => $className), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'createQuery', array('dql' => $dql), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'createNamedQuery', array('name' => $name), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'createQueryBuilder', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'flush', array('entity' => $entity), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'clear', array('entityName' => $entityName), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->clear($entityName);
    }

    public function close()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'close', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->close();
    }

    public function persist($entity)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'persist', array('entity' => $entity), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'remove', array('entity' => $entity), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'refresh', array('entity' => $entity), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'detach', array('entity' => $entity), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'merge', array('entity' => $entity), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getRepository', array('entityName' => $entityName), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'contains', array('entity' => $entity), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getEventManager', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getConfiguration', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'isOpen', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getUnitOfWork', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getProxyFactory', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'initializeObject', array('obj' => $obj), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'getFilters', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'isFiltersStateClean', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'hasFilters', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return $this->valueHolder6f976->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer6169f = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder6f976) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder6f976 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder6f976->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, '__get', ['name' => $name], $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        if (isset(self::$publicProperties8b405[$name])) {
            return $this->valueHolder6f976->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder6f976;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder6f976;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder6f976;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder6f976;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, '__isset', array('name' => $name), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder6f976;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder6f976;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, '__unset', array('name' => $name), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder6f976;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder6f976;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, '__clone', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        $this->valueHolder6f976 = clone $this->valueHolder6f976;
    }

    public function __sleep()
    {
        $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, '__sleep', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;

        return array('valueHolder6f976');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer6169f = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer6169f;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer6169f && ($this->initializer6169f->__invoke($valueHolder6f976, $this, 'initializeProxy', array(), $this->initializer6169f) || 1) && $this->valueHolder6f976 = $valueHolder6f976;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder6f976;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder6f976;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
